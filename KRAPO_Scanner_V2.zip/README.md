# KRAPO Scanner V2

Scanner Polymarket en lecture seule : découverte Gamma, carnets CLOB YES/NO, profondeur appariée, estimation des frais taker, historique, mouvements de prix indicatifs, tableau de bord et commandes Telegram.

**Aucun ordre n'est envoyé.** Un candidat calculé reste une estimation : les carnets changent, la taille affichée peut disparaître, les frais peuvent évoluer et les règles de résolution doivent être vérifiées manuellement.

## Ce que fait la V2

- Scan automatique des marchés actifs toutes les 30 minutes.
- Lecture des asks YES et NO et simulation de profondeur appariée niveau par niveau.
- Lecture du taux de frais par token via le endpoint public CLOB `/fee-rate` ; estimation taker selon la formule officielle `shares × fee_rate × p × (1-p)`.
- Un marché dont le taux de frais n'a pas pu être vérifié ne peut pas devenir un candidat net.
- Historique des scans dans `docs/data/history.json`.
- Regroupement informatif des contrats partageant le même événement Gamma. Cela ne prouve pas que leurs issues soient mutuellement exclusives ou exhaustives.
- Variation indicative du prix YES sur une heure pour les marchés les plus liquides (jusqu'à 40 par scan).
- Alertes Telegram sur les nouveaux candidats nets.
- Commandes Telegram : `/resume`, `/opportunites`, `/stats`, `/aide`.
- Tableau de bord GitHub Pages dans `docs/`.

## Architecture Telegram

GitHub Actions vérifie les commandes toutes les 5 minutes. Le bot n'est donc pas connecté en permanence : une commande peut mettre environ 0 à 5 minutes (parfois davantage si GitHub retarde un workflow) à recevoir sa réponse. Le scanner, lui, continue toutes les 30 minutes. Cette solution évite d'héberger un serveur permanent.

Le bot utilise le polling Telegram `getUpdates`. Un webhook Telegram déjà actif sur ce même bot doit être désactivé avant l'installation. Le bot doit être réservé à ce projet pour éviter que deux systèmes lisent les mêmes mises à jour.

## Mise à jour de ton dépôt existant

1. Garde le dépôt `Krapo6z/krapo-scanner` en **Public**.
2. Décompresse l'archive V2. Téléverse le contenu du dossier à la racine du dépôt en conservant exactement les dossiers `.github/`, `data/`, `docs/` et `tests/`.
3. Remplace les fichiers existants `scanner.py`, `README.md`, `requirements.txt`, `docs/index.html`, `docs/data/latest.json`, `docs/data/state.json` et `.github/workflows/scan.yml` par leurs versions V2.
4. Ajoute les nouveaux fichiers `telegram_commands.py`, `data/telegram_state.json`, `docs/data/history.json`, `tests/test_v2.py` et `.github/workflows/telegram_commands.yml`.
5. Dans GitHub, vérifie **Settings → Secrets and variables → Actions**. Les secrets existants `TELEGRAM_BOT_TOKEN` et `TELEGRAM_CHAT_ID` sont réutilisés. Ne les colle jamais dans le code.
6. Vérifie **Settings → Pages** : branche `main`, dossier `/docs`. Ne change rien si V1 est déjà publié ainsi.
7. Ouvre **Actions** et lance manuellement `KRAPO market scan` avec **Run workflow**.
8. Lance ensuite `KRAPO Telegram commands` avec **Run workflow**. Le bot enregistre le menu de commandes Telegram.
9. Dans Telegram, ouvre ton bot et envoie `/resume`. Les réponses automatiques seront ensuite vérifiées toutes les 5 minutes.

## Tests locaux

```bash
python -m unittest discover -s tests -v
python -m py_compile scanner.py telegram_commands.py
```

## Réglages GitHub Actions

Dans `.github/workflows/scan.yml` :

- `MARKET_LIMIT`: nombre maximal de marchés récupérés (120 par défaut).
- `MIN_LIQUIDITY`: liquidité minimale (100 $ par défaut).
- `NET_EDGE_MIN`: rendement net minimal estimé (0.01 = 1 %).

## Limites à connaître

- Les workflows planifiés GitHub ne garantissent pas une exécution à la minute exacte.
- Le poller Telegram peut répondre avec un délai, et il dépend de l'exécution du workflow toutes les 5 minutes.
- L'estimation de frais s'appuie sur le taux CLOB lu au moment du scan et sur la formule documentée ; le taux peut changer.
- La profondeur simulée est construite à partir des asks publics observés, pas d'une exécution réelle.
- Les regroupements d'événements sont des pistes de recherche, pas des preuves d'arbitrage logique.
- La variation sur une heure dépend de l'historique public disponible et peut être absente.
- Un dépôt public rend le code et les données du tableau de bord publics. Les secrets GitHub restent masqués ; ne publie jamais de token.

## Sources

- Gamma API : https://gamma-api.polymarket.com
- CLOB API : https://clob.polymarket.com
- Frais Polymarket : https://help.polymarket.com/en/articles/13364478-trading-fees
- Telegram Bot API : https://core.telegram.org/bots/api
- GitHub Actions schedule : https://docs.github.com/en/actions/using-workflows/events-that-trigger-workflows#schedule
