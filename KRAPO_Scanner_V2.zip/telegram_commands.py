#!/usr/bin/env python3
"""Scheduled Telegram command poller for KRAPO Scanner V2."""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

import requests

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "docs" / "data"
LATEST_FILE = DATA_DIR / "latest.json"
HISTORY_FILE = DATA_DIR / "history.json"
STATE_FILE = ROOT / "data" / "telegram_state.json"
TIMEOUT = 20
PARIS = ZoneInfo("Europe/Paris")


def load_json(path: Path, fallback):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return fallback


def api(token: str, method: str, payload=None):
    response = requests.post(
        f"https://api.telegram.org/bot{token}/{method}",
        json=payload or {}, timeout=TIMEOUT,
    )
    response.raise_for_status()
    data = response.json()
    if not data.get("ok"):
        raise RuntimeError(f"Telegram {method}: {data.get('description', 'erreur inconnue')}")
    return data.get("result")


def local_time(value):
    if not value:
        return "inconnue"
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(PARIS)
        return dt.strftime("%d/%m/%Y à %H:%M")
    except Exception:
        return str(value)


def money(value):
    if value is None:
        return "inconnu"
    return f"{float(value):.5f} $"


def format_resume(payload):
    if not payload:
        return "🐸 KRAPO V2\nAucun scan enregistré pour le moment. Lance un scan depuis GitHub Actions."
    lines = [
        "🐸 KRAPO V2 — RÉSUMÉ DU DERNIER SCAN",
        f"Dernier scan : {local_time(payload.get('generated_at'))}",
        "",
        f"Marchés découverts : {payload.get('markets_discovered', 0)}",
        f"Carnets exploitables : {payload.get('books_checked', 0)}",
        f"Erreurs de lecture : {payload.get('book_errors', 0)}",
        f"Candidats nets : {payload.get('candidate_count', 0)}",
        f"Taux de frais inconnus : {payload.get('fee_unknown_count', 0)}",
        f"Groupes d'événements liés : {payload.get('related_event_groups', 0)}",
        f"Alertes envoyées : {payload.get('telegram_alerts_sent', 0)}",
    ]
    candidates = payload.get("candidates") or []
    if candidates:
        lines.extend(["", "TOP 3 DES CANDIDATS NETS"])
        for index, item in enumerate(candidates[:3], 1):
            lines.append(
                f"{index}. {item.get('question', 'Marché')}\n"
                f"   Net estimé : {money(item.get('net_profit_estimated'))} · "
                f"Rendement : {float(item.get('net_edge') or 0) * 100:.2f}%\n"
                f"   Profondeur appariée : {float(item.get('executable_size') or 0):.2f} parts\n"
                f"   {item.get('url', '')}"
            )
    else:
        lines.extend(["", "Aucun candidat net n'a passé les seuils sur ce scan."])
    lines.extend(["", "Note : estimation sur les asks visibles à l'instant du scan, pas une garantie d'exécution."])
    return "\n".join(lines)


def format_opportunities(payload):
    candidates = (payload or {}).get("candidates") or []
    if not candidates:
        return "🐸 KRAPO V2 — OPPORTUNITÉS\nAucun candidat net sur le dernier scan."
    lines = [f"🐸 KRAPO V2 — {min(5, len(candidates))} MEILLEUR(S) CANDIDAT(S)", ""]
    for index, item in enumerate(candidates[:5], 1):
        lines.append(
            f"{index}. {item.get('question', 'Marché')}\n"
            f"Net estimé : {money(item.get('net_profit_estimated'))} · "
            f"Rendement : {float(item.get('net_edge') or 0) * 100:.2f}%\n"
            f"Taille appariée : {float(item.get('executable_size') or 0):.2f} parts\n"
            f"{item.get('url', '')}\n"
        )
    lines.append("À vérifier avant toute décision : frais, profondeur réelle, résolution et règles du marché.")
    return "\n".join(lines)


def format_stats(history):
    if not history:
        return "🐸 KRAPO V2 — STATS\nAucun historique disponible pour le moment."
    now = datetime.now(timezone.utc)
    last_24h = []
    for item in history:
        try:
            dt = datetime.fromisoformat(item["generated_at"].replace("Z", "+00:00"))
            if now - dt <= timedelta(hours=24):
                last_24h.append(item)
        except Exception:
            pass
    total_candidates = sum(int(item.get("candidate_count", 0)) for item in last_24h)
    total_markets = sum(int(item.get("markets_discovered", 0)) for item in last_24h)
    return "\n".join([
        "🐸 KRAPO V2 — STATS",
        f"Scans conservés : {len(history)}",
        f"Scans sur 24 h : {len(last_24h)}",
        f"Marchés examinés sur 24 h : {total_markets}",
        f"Candidats nets détectés sur 24 h : {total_candidates}",
        f"Dernier scan : {local_time(history[-1].get('generated_at'))}",
    ])


def main():
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()
    if not token or not chat_id:
        raise RuntimeError("Secrets TELEGRAM_BOT_TOKEN et TELEGRAM_CHAT_ID requis")

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    state = load_json(STATE_FILE, {"offset": 0})
    offset = int(state.get("offset", 0))

    webhook = api(token, "getWebhookInfo")
    if webhook and webhook.get("url"):
        raise RuntimeError("Un webhook Telegram est actif. Désactive-le avant d'utiliser le polling KRAPO.")

    # Publish the command list in Telegram's slash-command menu.
    api(token, "setMyCommands", {"commands": [
        {"command": "resume", "description": "Résumé du dernier scan KRAPO"},
        {"command": "opportunites", "description": "Meilleurs candidats du dernier scan"},
        {"command": "stats", "description": "Statistiques des scans"},
        {"command": "aide", "description": "Afficher les commandes KRAPO"},
    ]})

    updates = api(token, "getUpdates", {
        "offset": offset, "timeout": 0, "limit": 100,
        "allowed_updates": ["message"],
    }) or []
    latest = load_json(LATEST_FILE, {})
    history = load_json(HISTORY_FILE, [])
    processed = 0

    for update in updates:
        update_id = int(update.get("update_id", 0))
        message = update.get("message") or {}
        chat = message.get("chat") or {}
        text = (message.get("text") or "").strip()
        incoming_chat_id = str(chat.get("id", ""))
        # Ignore other chats; only the configured owner can query this bot.
        if incoming_chat_id == chat_id and text.startswith("/"):
            command = text.split()[0].split("@")[0].lower()
            if command == "/resume":
                answer = format_resume(latest)
            elif command == "/opportunites":
                answer = format_opportunities(latest)
            elif command == "/stats":
                answer = format_stats(history)
            elif command in ("/aide", "/start", "/help"):
                answer = "🐸 KRAPO V2 — COMMANDES\n/resume : résumé du dernier scan\n/opportunites : meilleurs candidats nets\n/stats : historique des scans"
            else:
                answer = "Commande inconnue. Envoie /aide pour voir les commandes disponibles."
            api(token, "sendMessage", {
                "chat_id": chat_id, "text": answer,
                "disable_web_page_preview": True,
            })
            processed += 1
        offset = max(offset, update_id + 1)

    state["offset"] = offset
    state["last_poll_at"] = datetime.now(timezone.utc).isoformat()
    STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Telegram command poll complete: {len(updates)} updates, {processed} owner commands, offset={offset}")


if __name__ == "__main__":
    main()
