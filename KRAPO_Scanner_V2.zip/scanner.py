#!/usr/bin/env python3
"""KRAPO Scanner V2 — read-only Polymarket market research scanner."""
from __future__ import annotations

import hashlib
import json
import os
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from zoneinfo import ZoneInfo

import requests

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "docs" / "data"
LATEST_FILE = DATA_DIR / "latest.json"
STATE_FILE = DATA_DIR / "state.json"
HISTORY_FILE = DATA_DIR / "history.json"
GAMMA = "https://gamma-api.polymarket.com"
CLOB = "https://clob.polymarket.com"
LIMIT = int(os.getenv("MARKET_LIMIT", "120"))
MIN_LIQUIDITY = float(os.getenv("MIN_LIQUIDITY", "100"))
NET_EDGE_MIN = float(os.getenv("NET_EDGE_MIN", "0.01"))
MAX_WORKERS = int(os.getenv("MAX_WORKERS", "8"))
ALERT_LIMIT = int(os.getenv("ALERT_LIMIT", "8"))
HISTORY_LIMIT = 500
TIMEOUT = 20
SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "KRAPO-Scanner/2.0 (read-only research bot)"})


def get_json(url: str, params: dict | None = None):
    response = SESSION.get(url, params=params, timeout=TIMEOUT)
    response.raise_for_status()
    return response.json()


def parse_jsonish(value, default):
    if isinstance(value, (list, dict)):
        return value
    if not value:
        return default
    try:
        return json.loads(value)
    except (TypeError, json.JSONDecodeError):
        return default


def number(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def round_fee(value: float) -> float:
    """Polymarket fee precision: 5 decimals, with a 0.00001 minimum if non-zero."""
    if value <= 0:
        return 0.0
    rounded = float(Decimal(str(value)).quantize(Decimal("0.00001"), rounding=ROUND_HALF_UP))
    return max(0.00001, rounded)


def fee_for_shares(shares: float, price: float, fee_rate: float) -> float:
    # Official taker fee model: shares × rate × p × (1-p).
    return round_fee(shares * fee_rate * price * (1.0 - price))


def fetch_markets():
    raw = get_json(
        f"{GAMMA}/markets",
        params={
            "active": "true", "closed": "false",
            "limit": min(max(LIMIT, 20), 500),
            "order": "liquidityNum", "ascending": "false",
        },
    )
    if not isinstance(raw, list):
        raise RuntimeError("Réponse Gamma inattendue : liste de marchés attendue")

    markets = []
    for market in raw:
        if not isinstance(market, dict):
            continue
        if market.get("closed") is True or market.get("active") is False:
            continue
        if market.get("enableOrderBook") is False:
            continue
        liquidity = number(market.get("liquidityNum", market.get("liquidity", 0)))
        if liquidity < MIN_LIQUIDITY:
            continue

        outcomes = parse_jsonish(market.get("outcomes"), [])
        token_ids = parse_jsonish(market.get("clobTokenIds"), [])
        if len(outcomes) != 2 or len(token_ids) != 2:
            continue
        pairs = {str(outcome).strip().lower(): str(token) for outcome, token in zip(outcomes, token_ids)}
        yes_id, no_id = pairs.get("yes"), pairs.get("no")
        if not yes_id or not no_id:
            continue

        events = market.get("events") if isinstance(market.get("events"), list) else []
        first_event = events[0] if events and isinstance(events[0], dict) else {}
        markets.append({
            "id": str(market.get("id", "")),
            "question": market.get("question") or "Marché sans titre",
            "slug": market.get("slug") or "",
            "event_slug": first_event.get("slug") or "",
            "event_title": first_event.get("title") or "",
            "liquidity": liquidity,
            "volume24h": number(market.get("volume24hr", 0)),
            "end_date": market.get("endDate") or market.get("endDateIso") or "",
            "yes_token": yes_id,
            "no_token": no_id,
            "fees_enabled_gamma": market.get("feesEnabled"),
            "url": f"https://polymarket.com/event/{market.get('slug')}" if market.get("slug") else "https://polymarket.com",
        })
    return markets


def parse_asks(book: dict) -> list[tuple[float, float]]:
    asks = book.get("asks") or []
    levels = []
    for level in asks:
        price = number(level.get("price"), -1)
        size = number(level.get("size"), 0)
        if 0 < price < 1 and size > 0:
            levels.append((price, size))
    return sorted(levels, key=lambda row: row[0])


def fetch_book(token_id: str) -> list[tuple[float, float]]:
    return parse_asks(get_json(f"{CLOB}/book", params={"token_id": token_id}))


def fetch_fee_rate(token_id: str, gamma_fees_enabled=None) -> tuple[float | None, str]:
    """Read the per-token CLOB fee rate. Return decimal rate and provenance."""
    try:
        payload = get_json(f"{CLOB}/fee-rate", params={"token_id": token_id})
        raw = payload.get("base_fee", payload.get("fee_rate_bps", payload.get("feeRateBps")))
        if raw is None:
            raw = payload.get("fee_rate")
            if raw is None:
                raise ValueError("champ de taux absent")
            rate = number(raw, -1)
            if rate < 0:
                raise ValueError("taux invalide")
            # fee_rate is already decimal when the API explicitly uses that field.
            return rate, "CLOB fee-rate"
        bps = number(raw, -1)
        if bps < 0:
            raise ValueError("base_fee invalide")
        return bps / 10000.0, "CLOB fee-rate"
    except Exception as exc:
        # Gamma explicitly marking fees disabled is a safe zero-fee fallback.
        if gamma_fees_enabled is False:
            return 0.0, "Gamma feesEnabled=false (fallback)"
        return None, f"taux indisponible: {str(exc)[:100]}"


def walk_paired_depth(yes_asks, no_asks, yes_fee_rate, no_fee_rate):
    """Match YES and NO asks level-by-level; stop once gross combined cost >= $1."""
    yi = ni = 0
    y_remaining = yes_asks[0][1] if yes_asks else 0.0
    n_remaining = no_asks[0][1] if no_asks else 0.0
    qty = gross_cost = fees = 0.0
    slices = []

    while yi < len(yes_asks) and ni < len(no_asks):
        yp = yes_asks[yi][0]
        np = no_asks[ni][0]
        if yp + np >= 1.0:
            break
        take = min(y_remaining, n_remaining)
        if take <= 0:
            break
        gross_cost += take * (yp + np)
        fees += fee_for_shares(take, yp, yes_fee_rate) + fee_for_shares(take, np, no_fee_rate)
        qty += take
        slices.append({"shares": take, "yes_price": yp, "no_price": np})
        y_remaining -= take
        n_remaining -= take
        if y_remaining <= 1e-12:
            yi += 1
            if yi < len(yes_asks):
                y_remaining = yes_asks[yi][1]
        if n_remaining <= 1e-12:
            ni += 1
            if ni < len(no_asks):
                n_remaining = no_asks[ni][1]

    if qty <= 0:
        return {"executable_size": 0.0, "gross_cost": 0.0, "fees_estimated": 0.0,
                "net_profit_estimated": 0.0, "net_edge": 0.0, "yes_vwap": None, "no_vwap": None}
    gross_profit = qty - gross_cost
    net_profit = gross_profit - fees
    total_outlay = gross_cost + fees
    return {
        "executable_size": qty,
        "gross_cost": gross_cost,
        "gross_profit_estimated": gross_profit,
        "fees_estimated": fees,
        "net_profit_estimated": net_profit,
        "net_edge": net_profit / total_outlay if total_outlay > 0 else 0.0,
        "yes_vwap": sum(s["shares"] * s["yes_price"] for s in slices) / qty,
        "no_vwap": sum(s["shares"] * s["no_price"] for s in slices) / qty,
        "depth_slices": len(slices),
    }


def fetch_price_change(token_id: str):
    try:
        payload = get_json(f"{CLOB}/prices-history", params={"market": token_id, "interval": "1h", "fidelity": 5})
        history = payload.get("history") or []
        points = [(int(p.get("t", 0)), number(p.get("p"), -1)) for p in history if p.get("p") is not None]
        points = sorted((t, p) for t, p in points if 0 < p < 1)
        if len(points) < 2:
            return None
        first, last = points[0][1], points[-1][1]
        return {"start": first, "last": last, "change": last - first, "points": len(points)}
    except Exception:
        return None


def scan_one(market):
    try:
        yes_asks = fetch_book(market["yes_token"])
        no_asks = fetch_book(market["no_token"])
        if not yes_asks or not no_asks:
            return {**market, "error": "Carnet sans ask exploitable"}
        yes_rate, yes_fee_source = fetch_fee_rate(market["yes_token"], market.get("fees_enabled_gamma"))
        no_rate, no_fee_source = fetch_fee_rate(market["no_token"], market.get("fees_enabled_gamma"))
        fee_verified = yes_rate is not None and no_rate is not None
        if fee_verified:
            depth = walk_paired_depth(yes_asks, no_asks, yes_rate, no_rate)
        else:
            depth = walk_paired_depth(yes_asks, no_asks, 0.0, 0.0)
            depth["net_profit_estimated"] = None
            depth["net_edge"] = None

        yes_best, no_best = yes_asks[0], no_asks[0]
        combined = yes_best[0] + no_best[0]
        gross_edge = 1.0 - combined
        top_size = min(yes_best[1], no_best[1])
        candidate = bool(
            fee_verified and depth["net_profit_estimated"] is not None
            and depth["net_profit_estimated"] > 0
            and depth["net_edge"] >= NET_EDGE_MIN
        )
        return {
            **market,
            "yes_best_ask": yes_best[0], "yes_ask_size": yes_best[1],
            "no_best_ask": no_best[0], "no_ask_size": no_best[1],
            "combined_cost": combined, "gross_edge": gross_edge,
            "matched_top_size": top_size,
            "yes_fee_rate": yes_rate, "no_fee_rate": no_rate,
            "fee_verified": fee_verified,
            "fee_source": f"YES: {yes_fee_source}; NO: {no_fee_source}",
            **depth,
            "candidate": candidate,
            "fee_status": "Taux CLOB vérifiés" if fee_verified else "Frais inconnus : candidat bloqué",
            "checked_at": datetime.now(timezone.utc).isoformat(),
        }
    except Exception as exc:
        return {"id": market.get("id", ""), "question": market.get("question", ""), "error": str(exc)[:180]}


def telegram_send(text: str):
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()
    if not token or not chat_id:
        return False
    response = requests.post(
        f"https://api.telegram.org/bot{token}/sendMessage",
        json={"chat_id": chat_id, "text": text, "disable_web_page_preview": True},
        timeout=TIMEOUT,
    )
    response.raise_for_status()
    return True


def load_json(path: Path, fallback):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return fallback


def alert_key(item):
    raw = f"{item.get('id')}|{item.get('yes_best_ask')}|{item.get('no_best_ask')}|{item.get('net_profit_estimated')}"
    return hashlib.sha256(raw.encode()).hexdigest()[:20]


def format_alert(item):
    return (
        "🟢 KRAPO V2 — candidat net détecté\n\n"
        f"{item['question']}\n"
        f"YES ask : {item['yes_best_ask']:.3f} $ · NO ask : {item['no_best_ask']:.3f} $\n"
        f"Écart brut au meilleur prix : {item['gross_edge'] * 100:.2f} %\n"
        f"Profondeur appariée estimée : {item['executable_size']:.2f} parts\n"
        f"Frais estimés : {item['fees_estimated']:.5f} $\n"
        f"Profit net estimé : {item['net_profit_estimated']:.5f} $\n"
        f"Rendement net estimé : {item['net_edge'] * 100:.2f} %\n"
        "⚠️ Estimation sur carnets lus à l'instant T, pas une garantie d'exécution. Vérifier résolution et règles.\n"
        f"{item['url']}"
    )


def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    started = datetime.now(timezone.utc)
    markets = fetch_markets()
    results = []
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
        futures = [pool.submit(scan_one, market) for market in markets]
        for future in as_completed(futures):
            results.append(future.result())

    valid = [item for item in results if "error" not in item]
    candidates = sorted(
        [item for item in valid if item.get("candidate")],
        key=lambda item: item.get("net_profit_estimated", 0), reverse=True,
    )

    # Group contracts sharing the same Gamma event. This is a research cluster,
    # not proof that their outcomes are mutually exclusive or exhaustive.
    event_groups = defaultdict(list)
    for item in valid:
        if item.get("event_slug"):
            event_groups[item["event_slug"]].append(item)
    for item in valid:
        item["related_market_count"] = len(event_groups.get(item.get("event_slug"), [])) if item.get("event_slug") else 1

    # Price-movement check on the most liquid markets to keep API calls bounded.
    movers = sorted(valid, key=lambda item: item.get("liquidity", 0), reverse=True)[:min(40, len(valid))]
    with ThreadPoolExecutor(max_workers=min(8, MAX_WORKERS)) as pool:
        move_futures = {pool.submit(fetch_price_change, item["yes_token"]): item for item in movers}
        for future in as_completed(move_futures):
            move_futures[future]["yes_price_change_1h"] = future.result()

    state = load_json(STATE_FILE, {"sent_alert_keys": []})
    sent_keys = set(state.get("sent_alert_keys", []))
    new_alerts = []
    for item in candidates:
        key = alert_key(item)
        if key not in sent_keys:
            new_alerts.append((key, item))

    sent_count = 0
    for key, item in new_alerts[:ALERT_LIMIT]:
        try:
            if telegram_send(format_alert(item)):
                sent_count += 1
                sent_keys.add(key)
        except Exception as exc:
            print(f"Telegram error: {exc}")
    state["sent_alert_keys"] = sorted(sent_keys)[-3000:]
    STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")

    now = datetime.now(timezone.utc)
    payload = {
        "project": "KRAPO Scanner", "version": "2.0.0",
        "generated_at": now.isoformat(),
        "duration_seconds": round((now - started).total_seconds(), 2),
        "markets_discovered": len(markets), "books_checked": len(valid),
        "book_errors": len(results) - len(valid),
        "candidate_count": len(candidates),
        "gross_candidate_count": sum(1 for item in valid if item.get("gross_edge", 0) >= NET_EDGE_MIN),
        "fee_unknown_count": sum(1 for item in valid if not item.get("fee_verified")),
        "telegram_alerts_sent": sent_count,
        "related_event_groups": len(event_groups),
        "markets_with_price_history": sum(1 for item in valid if item.get("yes_price_change_1h")),
        "settings": {
            "market_limit": LIMIT, "minimum_liquidity_usd": MIN_LIQUIDITY,
            "minimum_net_edge": NET_EDGE_MIN,
            "fee_formula": "shares × fee_rate × p × (1-p), fee rate read from CLOB per token",
            "note": "Candidate net estimé uniquement si le taux de frais a été lu. Profondeur simulée sur asks visibles; aucune exécution ni garantie.",
        },
        "candidates": candidates[:100],
        "markets": sorted(valid, key=lambda item: item.get("liquidity", 0), reverse=True)[:100],
        "errors": [item for item in results if "error" in item][:30],
    }
    LATEST_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    history = load_json(HISTORY_FILE, [])
    history.append({
        "generated_at": payload["generated_at"],
        "markets_discovered": payload["markets_discovered"],
        "books_checked": payload["books_checked"],
        "book_errors": payload["book_errors"],
        "candidate_count": payload["candidate_count"],
        "fee_unknown_count": payload["fee_unknown_count"],
    })
    HISTORY_FILE.write_text(json.dumps(history[-HISTORY_LIMIT:], ensure_ascii=False, indent=2), encoding="utf-8")

    print(json.dumps({key: payload[key] for key in (
        "generated_at", "markets_discovered", "books_checked", "book_errors",
        "candidate_count", "fee_unknown_count", "telegram_alerts_sent",
    )}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
