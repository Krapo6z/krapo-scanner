import sys
import unittest
import json
import tempfile
from unittest.mock import patch
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import scanner
import telegram_commands


class ScannerMathTests(unittest.TestCase):
    def test_fee_formula(self):
        self.assertAlmostEqual(scanner.fee_for_shares(10, 0.5, 0.05), 0.125)

    def test_fee_rate_reads_basis_points(self):
        with patch.object(scanner, "get_json", return_value={"base_fee": 1000}):
            rate, source = scanner.fetch_fee_rate("token-1", True)
        self.assertAlmostEqual(rate, 0.10)
        self.assertIn("CLOB", source)

    def test_fee_rate_gamma_disabled_fallback(self):
        with patch.object(scanner, "get_json", side_effect=RuntimeError("offline")):
            rate, source = scanner.fetch_fee_rate("token-1", False)
        self.assertEqual(rate, 0.0)
        self.assertIn("fallback", source)

    def test_fee_minimum_rounding(self):
        self.assertEqual(scanner.round_fee(0.000001), 0.00001)
        self.assertEqual(scanner.round_fee(0), 0)

    def test_paired_depth_and_net_profit(self):
        yes = [(0.40, 5), (0.42, 5)]
        no = [(0.50, 5), (0.52, 5)]
        result = scanner.walk_paired_depth(yes, no, 0.0, 0.0)
        self.assertEqual(result["executable_size"], 10)
        self.assertGreater(result["net_profit_estimated"], 0)
        self.assertAlmostEqual(result["yes_vwap"], 0.41)
        self.assertAlmostEqual(result["no_vwap"], 0.51)

    def test_depth_stops_at_or_above_one(self):
        result = scanner.walk_paired_depth([(0.6, 10)], [(0.4, 10)], 0, 0)
        self.assertEqual(result["executable_size"], 0)

    def test_fee_unknown_blocks_candidate_logic(self):
        # The production candidate condition requires both fee rates to be known.
        yes_rate, no_rate = None, 0.0
        self.assertFalse(yes_rate is not None and no_rate is not None)

    def test_scan_main_writes_latest_and_history(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            latest, state, history = root / "latest.json", root / "state.json", root / "history.json"
            candidate = {
                "id": "1", "question": "Test market", "event_slug": "test-event",
                "yes_token": "yes", "url": "https://polymarket.com/event/test",
                "candidate": True, "net_profit_estimated": 0.2, "net_edge": 0.02,
                "gross_edge": 0.03, "executable_size": 10, "fees_estimated": 0.1,
                "yes_best_ask": 0.4, "no_best_ask": 0.57,
            }
            with patch.object(scanner, "DATA_DIR", root), \
                 patch.object(scanner, "LATEST_FILE", latest), \
                 patch.object(scanner, "STATE_FILE", state), \
                 patch.object(scanner, "HISTORY_FILE", history), \
                 patch.object(scanner, "fetch_markets", return_value=[{"id": "1"}]), \
                 patch.object(scanner, "scan_one", return_value=candidate), \
                 patch.object(scanner, "fetch_price_change", return_value=None), \
                 patch.object(scanner, "telegram_send", return_value=False):
                scanner.main()
            data = json.loads(latest.read_text())
            hist = json.loads(history.read_text())
            self.assertEqual(data["version"], "2.0.0")
            self.assertEqual(data["candidate_count"], 1)
            self.assertEqual(len(hist), 1)


class TelegramFormatTests(unittest.TestCase):
    def test_resume_without_scan(self):
        self.assertIn("Aucun scan", telegram_commands.format_resume({}))

    def test_opportunities_without_candidates(self):
        self.assertIn("Aucun candidat", telegram_commands.format_opportunities({"candidates": []}))

    def test_stats_empty(self):
        self.assertIn("Aucun historique", telegram_commands.format_stats([]))

    def test_resume_includes_latest_candidate(self):
        payload = {"generated_at": "2026-11-09T12:00:00+00:00", "markets_discovered": 10,
                   "books_checked": 9, "candidate_count": 1, "fee_unknown_count": 0,
                   "related_event_groups": 2, "telegram_alerts_sent": 1,
                   "candidates": [{"question": "Test market", "net_profit_estimated": 0.12,
                                   "net_edge": 0.02, "executable_size": 5, "url": "https://example.com"}]}
        result = telegram_commands.format_resume(payload)
        self.assertIn("Test market", result)
        self.assertIn("Candidats nets : 1", result)

    def test_command_poller_answers_owner_and_saves_offset(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            state = root / "telegram_state.json"
            latest = root / "latest.json"
            history = root / "history.json"
            latest.write_text(json.dumps({"generated_at": "2026-11-09T12:00:00+00:00", "candidate_count": 0, "candidates": []}))
            history.write_text("[]")
            calls = []
            def fake_api(token, method, payload=None):
                if method == "getWebhookInfo": return {"url": ""}
                if method == "getUpdates": return [{"update_id": 42, "message": {"chat": {"id": 123}, "text": "/resume"}}]
                if method == "sendMessage": calls.append(payload); return {"message_id": 7}
                return True
            with patch.object(telegram_commands, "STATE_FILE", state), \
                 patch.object(telegram_commands, "LATEST_FILE", latest), \
                 patch.object(telegram_commands, "HISTORY_FILE", history), \
                 patch.object(telegram_commands, "api", side_effect=fake_api), \
                 patch.dict("os.environ", {"TELEGRAM_BOT_TOKEN": "test-token", "TELEGRAM_CHAT_ID": "123"}):
                telegram_commands.main()
            self.assertEqual(len(calls), 1)
            self.assertIn("RÉSUMÉ DU DERNIER SCAN", calls[0]["text"])
            self.assertEqual(json.loads(state.read_text())["offset"], 43)


if __name__ == "__main__":
    unittest.main()
